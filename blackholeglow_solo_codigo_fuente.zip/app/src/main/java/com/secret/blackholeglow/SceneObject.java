// SceneObject.java
package com.secret.blackholeglow;

public interface SceneObject {
    void update(float deltaTime);
    void draw();
}